import javax.swing.*;
import java.awt.*;

public class Main {

    public static void main(String[] args) {
        // Connect to the database
        DatabaseConnection.connectToDatabase();

        // Launch the UI
        SwingUtilities.invokeLater(() -> {
            setupUI();
        });
    }

    private static void setupUI() {
        JFrame frame = new JFrame("Library Management");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        frame.getContentPane().setBackground(Color.decode("#f0f0f0"));

        JPanel mainPanel = new JPanel(new BorderLayout());
        frame.add(mainPanel, BorderLayout.CENTER);

        JPanel headingPanel = new JPanel();
        JLabel headingLabel = new JLabel("Library Management System");
        headingLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headingPanel.add(headingLabel);
        headingPanel.setBackground(Color.decode("#2196F3"));
        mainPanel.add(headingPanel, BorderLayout.NORTH);

        JPanel menuPanel = new JPanel(new GridLayout(3, 3, 10, 10));
        menuPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        mainPanel.add(menuPanel, BorderLayout.CENTER);

        JButton addBookBtn = new JButton("Add New Book");
        JButton addBorrowerBtn = new JButton("Add New Borrower");
        JButton borrowBookBtn = new JButton("Borrow a Book");
        JButton returnBookBtn = new JButton("Return a Book");
        JButton searchBooksBtn = new JButton("Search for Books");
        JButton viewHistoryBtn = new JButton("View Borrowing History");

        Font buttonFont = new Font("Arial", Font.BOLD, 16);
        Color buttonColor = Color.decode("#00BCD4");
        addBookBtn.setFont(buttonFont);
        addBookBtn.setBackground(buttonColor);
        addBorrowerBtn.setFont(buttonFont);
        addBorrowerBtn.setBackground(buttonColor);
        borrowBookBtn.setFont(buttonFont);
        borrowBookBtn.setBackground(buttonColor);
        returnBookBtn.setFont(buttonFont);
        returnBookBtn.setBackground(buttonColor);
        searchBooksBtn.setFont(buttonFont);
        searchBooksBtn.setBackground(buttonColor);
        viewHistoryBtn.setFont(buttonFont);
        viewHistoryBtn.setBackground(buttonColor);

        menuPanel.add(addBookBtn);
        menuPanel.add(addBorrowerBtn);
        menuPanel.add(borrowBookBtn);
        menuPanel.add(returnBookBtn);
        menuPanel.add(searchBooksBtn);
        menuPanel.add(viewHistoryBtn);

        addBookBtn.addActionListener(e -> BookOperations.addNewBook());
        addBorrowerBtn.addActionListener(e -> BorrowerOperations.addNewBorrower());
        borrowBookBtn.addActionListener(e -> TransactionOperations.borrowBook());
        returnBookBtn.addActionListener(e -> TransactionOperations.returnBook());
        searchBooksBtn.addActionListener(e -> BookOperations.searchBooks());
        viewHistoryBtn.addActionListener(e -> TransactionOperations.viewBorrowingHistory());

        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
