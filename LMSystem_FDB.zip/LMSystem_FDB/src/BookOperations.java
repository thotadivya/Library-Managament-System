import javax.swing.*;
import java.awt.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BookOperations {

    public static void addNewBook() {
        JTextField isbnField = new JTextField(10);
        JTextField titleField = new JTextField(20);
        JTextField authorField = new JTextField(20);
        JTextField genreField = new JTextField(20);
        JTextField yearField = new JTextField(10);

        JPanel panel = new JPanel(new GridLayout(0, 1));
        panel.setBorder(BorderFactory.createTitledBorder("Add New Book"));
        panel.setBackground(Color.decode("#e6eeff"));

        panel.add(createLabel("ISBN:"));
        panel.add(isbnField);
        panel.add(createLabel("Title:"));
        panel.add(titleField);
        panel.add(createLabel("Author:"));
        panel.add(authorField);
        panel.add(createLabel("Genre:"));
        panel.add(genreField);
        panel.add(createLabel("Publication Year:"));
        panel.add(yearField);

        int result = JOptionPane.showConfirmDialog(null, panel, "Add New Book", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                PreparedStatement preparedStatement = DatabaseConnection.dbConnection.prepareStatement("INSERT INTO books (isbn, title, author, genre, publication_year) VALUES (?, ?, ?, ?, ?)");
                preparedStatement.setString(1, isbnField.getText());
                preparedStatement.setString(2, titleField.getText());
                preparedStatement.setString(3, authorField.getText());
                preparedStatement.setString(4, genreField.getText());
                preparedStatement.setInt(5, Integer.parseInt(yearField.getText()));
                preparedStatement.executeUpdate();

                JOptionPane.showMessageDialog(null, "Book added successfully.");
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Failed to add book.");
            }
        }
    }

    public static void searchBooks() {
        JTextField keywordField = new JTextField(20);
        JPanel panel = new JPanel(new GridLayout(0, 1));
        panel.setBorder(BorderFactory.createTitledBorder("Search for Books"));
        panel.setBackground(Color.decode("#e6eeff"));
        panel.add(createLabel("Search Keyword:"));
        panel.add(keywordField);

        int result = JOptionPane.showConfirmDialog(null, panel, "Search for Books", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            String keyword = keywordField.getText();
            try {
                PreparedStatement preparedStatement = DatabaseConnection.dbConnection.prepareStatement("SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR genre LIKE ?");
                preparedStatement.setString(1, "%" + keyword + "%");
                preparedStatement.setString(2, "%" + keyword + "%");
                preparedStatement.setString(3, "%" + keyword + "%");

                ResultSet resultSet = preparedStatement.executeQuery();
                StringBuilder results = new StringBuilder();
                while (resultSet.next()) {
                    results.append("ISBN: ").append(resultSet.getString("isbn"))
                            .append(", Title: ").append(resultSet.getString("title"))
                            .append(", Author: ").append(resultSet.getString("author"))
                            .append(", Genre: ").append(resultSet.getString("genre"))
                            .append("\n");
                }
                JOptionPane.showMessageDialog(null, results.toString());
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Failed to search books.");
            }
        }
    }

    private static JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.BOLD, 14));
        return label;
    }
}
