import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnection {
    public static Connection dbConnection;

    public static void connectToDatabase() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            dbConnection = DriverManager.getConnection("jdbc:mysql://localhost:3306/LMS_FDB", "root", "root");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
