import javax.swing.*;
import java.awt.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

public class TransactionOperations {

    public static void borrowBook() {
        JTextField borrowerIdField = new JTextField(10);
        JTextField isbnField = new JTextField(10);

        JPanel panel = new JPanel(new GridLayout(0, 1));
        panel.setBorder(BorderFactory.createTitledBorder("Borrow a Book"));
        panel.setBackground(Color.decode("#e6eeff"));

        panel.add(createLabel("Borrower ID:"));
        panel.add(borrowerIdField);
        panel.add(createLabel("Book ISBN:"));
        panel.add(isbnField);

        int result = JOptionPane.showConfirmDialog(null, panel, "Borrow a Book", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                PreparedStatement preparedStatement = DatabaseConnection.dbConnection.prepareStatement("INSERT INTO borrowing_transactions (borrower_id, isbn, borrowing_date) VALUES (?, ?, ?)");
                preparedStatement.setInt(1, Integer.parseInt(borrowerIdField.getText()));
                preparedStatement.setString(2, isbnField.getText());
                preparedStatement.setDate(3, java.sql.Date.valueOf(LocalDate.now()));
                preparedStatement.executeUpdate();
                JOptionPane.showMessageDialog(null, "Book borrowed successfully.");
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Failed to borrow book.");
            }
        }
    }

    public static void returnBook() {
        JTextField transactionIdField = new JTextField(10);

        JPanel panel = new JPanel(new GridLayout(0, 1));
        panel.setBorder(BorderFactory.createTitledBorder("Return a Book"));
        panel.setBackground(Color.decode("#e6eeff"));

        panel.add(createLabel("Transaction ID:"));
        panel.add(transactionIdField);

        int result = JOptionPane.showConfirmDialog(null, panel, "Return a Book", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                PreparedStatement preparedStatement = DatabaseConnection.dbConnection.prepareStatement("UPDATE borrowing_transactions SET return_date = ? WHERE transaction_id = ?");
                preparedStatement.setDate(1, java.sql.Date.valueOf(LocalDate.now()));
                preparedStatement.setInt(2, Integer.parseInt(transactionIdField.getText()));
                preparedStatement.executeUpdate();
                JOptionPane.showMessageDialog(null, "Book returned successfully.");
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Failed to return book.");
            }
        }
    }

    public static void viewBorrowingHistory() {
        JTextField borrowerIdField = new JTextField(10);

        JPanel panel = new JPanel(new GridLayout(0, 1));
        panel.add(createLabel("Borrower ID:"));
        panel.add(borrowerIdField);

        int result = JOptionPane.showConfirmDialog(null, panel, "View Borrowing History", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                PreparedStatement preparedStatement = DatabaseConnection.dbConnection.prepareStatement("SELECT * FROM borrowing_transactions WHERE borrower_id = ?");
                preparedStatement.setInt(1, Integer.parseInt(borrowerIdField.getText()));
                ResultSet resultSet = preparedStatement.executeQuery();

                StringBuilder history = new StringBuilder("Borrowing History:\n");
                while (resultSet.next()) {
                    history.append("ISBN: ").append(resultSet.getString("isbn"))
                            .append(", Borrowing Date: ").append(resultSet.getDate("borrowing_date"))
                            .append(", Return Date: ").append(resultSet.getDate("return_date"))
                            .append("\n");
                }
                resultSet.close();
                JOptionPane.showMessageDialog(null, history.toString());
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Failed to view borrowing history.");
            }
        }
    }

    private static JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.BOLD, 14));
        return label;
    }
}
