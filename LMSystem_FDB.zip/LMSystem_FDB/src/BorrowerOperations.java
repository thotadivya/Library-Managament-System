import javax.swing.*;
import java.awt.*;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class BorrowerOperations {

    public static void addNewBorrower() {
        JTextField nameField = new JTextField(20);
        JTextField emailField = new JTextField(20);
        JTextField contactField = new JTextField(15);

        JPanel panel = new JPanel(new GridLayout(0, 1));
        panel.setBorder(BorderFactory.createTitledBorder("Add New Borrower"));
        panel.setBackground(Color.decode("#e6eeff"));

        panel.add(createLabel("Name:"));
        panel.add(nameField);
        panel.add(createLabel("Email:"));
        panel.add(emailField);
        panel.add(createLabel("Contact Number:"));
        panel.add(contactField);

        int result = JOptionPane.showConfirmDialog(null, panel, "Add New Borrower", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                PreparedStatement preparedStatement = DatabaseConnection.dbConnection.prepareStatement("INSERT INTO borrowers (name, email, contact_number) VALUES (?, ?, ?)");
                preparedStatement.setString(1, nameField.getText());
                preparedStatement.setString(2, emailField.getText());
                preparedStatement.setString(3, contactField.getText());
                preparedStatement.executeUpdate();
                JOptionPane.showMessageDialog(null, "Borrower added successfully.");
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Failed to add borrower.");
            }
        }
    }

    private static JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.BOLD, 14));
        return label;
    }
}
